package com.example.hp.deliver;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class registration extends AppCompatActivity {
    EditText n;
    EditText e;
    EditText p;
    FirebaseAuth auth;
    FirebaseUser user;
    DatabaseReference ref;
    FirebaseDatabase data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
    }

    public void register(View view)
    {
        auth=FirebaseAuth.getInstance();
        user=auth.getCurrentUser();
        data=FirebaseDatabase.getInstance();
        ref=data.getReference();
        n=findViewById(R.id.name);
        e=findViewById(R.id.email);
        p=findViewById(R.id.pass);
        final String name = n.getText().toString().trim();
        if(TextUtils.isEmpty(name)){
            Toast.makeText(this,"Name Not Provided",Toast.LENGTH_SHORT).show();
            return;}
        final String email = e.getText().toString().trim();
        if(TextUtils.isEmpty(email)){
            Toast.makeText(this,"Email Not Provided",Toast.LENGTH_SHORT).show();
            return;}
        final String pass = p.getText().toString().trim();
        if(TextUtils.isEmpty(pass)){
            Toast.makeText(this,"Password Not Provided",Toast.LENGTH_SHORT).show();
            return;}
        if(pass.length()<6){
            Toast.makeText(this,"Password Length Should Be Greater Than 6",Toast.LENGTH_SHORT).show();
            return;
        }
        Toast.makeText(registration.this,"Please wait we are trying to connect to the servers",Toast.LENGTH_SHORT).show();
        auth.createUserWithEmailAndPassword(email, pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task)
            {
                if (task.isSuccessful())
                {
                    auth.getCurrentUser().sendEmailVerification();
                    Toast.makeText(registration.this, "Registration Successful Please Verify Email and Login", Toast.LENGTH_SHORT).show();
                    // user_details user = new user_details(name, email, registration,type,first_time);
                    ref.child("Students").child(auth.getUid()).setValue(name);
                    auth.signOut();
                    Intent i = new Intent(registration.this, login_page.class);
                    startActivity(i);
                    finish();
                    //  progressBar.setVisibility(View.INVISIBLE);
                } else
                    Toast.makeText(registration.this, "Registration Unsuccessful Contact Support", Toast.LENGTH_SHORT).show();
            }
        });
    }



    }

